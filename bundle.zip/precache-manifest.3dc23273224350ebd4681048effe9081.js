self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aee3d60f60ba8e945e842d464d3a77b5",
    "url": "/index.html"
  },
  {
    "revision": "c005b1d64035b49fd6e4",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "b1d882f53748fae45633",
    "url": "/static/css/main.9da1cf83.chunk.css"
  },
  {
    "revision": "c005b1d64035b49fd6e4",
    "url": "/static/js/2.f276050a.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.f276050a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b1d882f53748fae45633",
    "url": "/static/js/main.c8533783.chunk.js"
  },
  {
    "revision": "a40f092681be38c2f735",
    "url": "/static/js/runtime-main.a6beca31.js"
  },
  {
    "revision": "9f4439724bddf0e6b8db2f2de4e29889",
    "url": "/static/media/COIN.9f443972.png"
  },
  {
    "revision": "11eabca2251325cfc5589c9c6fb57b46",
    "url": "/static/media/Roboto-Regular.11eabca2.ttf"
  },
  {
    "revision": "cd619a4f068dc66cc6e58fe0a91a8a34",
    "url": "/static/media/Rubik-Regular.cd619a4f.ttf"
  },
  {
    "revision": "0ee53eef15363cd18b45ce6c3d22a73a",
    "url": "/static/media/TTCommons-Regular.0ee53eef.woff"
  },
  {
    "revision": "e026266e4d31bdb9921fad7ff7588656",
    "url": "/static/media/TTCommons-Regular.e026266e.eot"
  },
  {
    "revision": "fc6fbc1addf37a7f957715e41b20291d",
    "url": "/static/media/TTCommons-Regular.fc6fbc1a.ttf"
  },
  {
    "revision": "cf904062715c4c113bec68532c058af9",
    "url": "/static/media/ball.cf904062.png"
  },
  {
    "revision": "f1294bc201963202abd1ac9c3fa52ecd",
    "url": "/static/media/cancel.f1294bc2.svg"
  },
  {
    "revision": "e7cc089d2163e797ca71857036133406",
    "url": "/static/media/common_chest.e7cc089d.svg"
  },
  {
    "revision": "682b92212e05954ec84662af06d939b4",
    "url": "/static/media/dices.682b9221.svg"
  },
  {
    "revision": "839aee7465ce21d2a451522bf99b3722",
    "url": "/static/media/epic_chest.839aee74.svg"
  },
  {
    "revision": "14e7ab95cc6bac4e9e2c7646ffb7c6f5",
    "url": "/static/media/jackpot.14e7ab95.svg"
  },
  {
    "revision": "7e66637ff5ebdf3876435ed081a6fff5",
    "url": "/static/media/rare_chest.7e66637f.svg"
  },
  {
    "revision": "ba666a6fcf6e25af45491054c4798d60",
    "url": "/static/media/roulette.ba666a6f.svg"
  },
  {
    "revision": "c95fffcc9ca5542f88ee6360dbb75e68",
    "url": "/static/media/round.c95fffcc.png"
  },
  {
    "revision": "d9e030e5a4664e6ebed6d8e1648fd031",
    "url": "/static/media/shop.d9e030e5.svg"
  },
  {
    "revision": "9bfda01ff41f6ed0e18a7c7a5416ad57",
    "url": "/static/media/star.9bfda01f.svg"
  },
  {
    "revision": "7923f90c7d4cbcbe7bd01a799352474f",
    "url": "/static/media/stock-exchange-app.7923f90c.svg"
  },
  {
    "revision": "e1c6e858e070f054266517fe33071637",
    "url": "/static/media/stop.e1c6e858.svg"
  },
  {
    "revision": "17b97ab5a543e1fde0403e76d80756ce",
    "url": "/static/media/verified.17b97ab5.svg"
  },
  {
    "revision": "b03024c4d635b0a304e483e1d9fa34d8",
    "url": "/static/media/vk.b03024c4.svg"
  }
]);